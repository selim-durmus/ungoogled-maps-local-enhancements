## [1.7.4](https://github.com/bearinmindcat/morphe-patches/compare/v1.7.3...v1.7.4) (2026-10-07)

### 🐛 Bug Fixes

* pull from google account in ungoogled maps' local saved too ([b5e4b94](https://github.com/bearinmindcat/morphe-patches/commit/b5e4b940e8a11f7e3fadfd6d6279a2b8f17f935e))

## [1.7.3](https://github.com/bearinmindcat/morphe-patches/compare/v1.7.2...v1.7.3) (2026-10-07)

### 🐛 Bug Fixes

* local saved in microG Maps, with pull from Google account ([c6b8d13](https://github.com/bearinmindcat/morphe-patches/commit/c6b8d13c94d12b10fb50527680e6e0440cd0731a))

## [1.7.2](https://github.com/bearinmindcat/morphe-patches/compare/v1.7.1...v1.7.2) (2026-10-07)

### 🐛 Bug Fixes

* power saving options has its own row on the account sheet ([b30ab45](https://github.com/bearinmindcat/morphe-patches/commit/b30ab4502ec2dddb2b4a056906c7e21de5f67e53))

## [1.7.1](https://github.com/bearinmindcat/morphe-patches/compare/v1.7.0...v1.7.1) (2026-10-07)

### 🐛 Bug Fixes

* account picture stays round inside its ring ([54b9f9f](https://github.com/bearinmindcat/morphe-patches/commit/54b9f9f745783799483c09fa968778ad32f97d9c))
* microG Maps no longer crashes or freezes at start ([c7d4723](https://github.com/bearinmindcat/morphe-patches/commit/c7d472383ff4d196fefa3bb0f7abf50995546ddd))
* splash screen shows the app's own icon ([b2d512e](https://github.com/bearinmindcat/morphe-patches/commit/b2d512e655db74a34d8564e69283d07841cf63bb))

## [1.6.0](https://github.com/bearinmindcat/morphe-patches/compare/v1.5.1...v1.6.0) (2026-10-07)

### ✨ New Features

* add microG Maps (separate app that signs in through MicroG-RE) ([78d3edc](https://github.com/bearinmindcat/morphe-patches/commit/78d3edcac5f9fd458f87216d8f84197b0c5e3a97))
* give microG Maps its own icon ([920a8ad](https://github.com/bearinmindcat/morphe-patches/commit/920a8ad26013ac3fdfa8805bed765d3f436c4a10))

## [1.5.1](https://github.com/bearinmindcat/morphe-patches/compare/v1.5.0...v1.5.1) (2026-10-07)

### 🐛 Bug Fixes

* merge related patches into fewer patches (33 to 21) ([871e40b](https://github.com/bearinmindcat/morphe-patches/commit/871e40b8ba3e2ace5ef2c393aa79c2593746a1ff))

## [1.5.0](https://github.com/bearinmindcat/morphe-patches/compare/v1.4.4...v1.5.0) (2026-10-07)

### ✨ New Features

* add power saving options (open without locking, idle switch, speedometer, lower frame rate, black map) ([3ce8b9d](https://github.com/bearinmindcat/morphe-patches/commit/3ce8b9df60dd458234d1b1660e64899edea1e277))

## [1.4.4](https://github.com/bearinmindcat/morphe-patches/compare/v1.4.3...v1.4.4) (2026-10-06)

### 🐛 Bug Fixes

* 120 refresh rate now keeps navigation smooth ([f323173](https://github.com/bearinmindcat/morphe-patches/commit/f32317373b574bbe89eb45964bac18c5addb0090))

## [1.4.3](https://github.com/bearinmindcat/morphe-patches/compare/v1.4.2...v1.4.3) (2026-10-06)

### 🐛 Bug Fixes

* customization screen no longer removes other account menu rows ([269e0ef](https://github.com/bearinmindcat/morphe-patches/commit/269e0ef335990d713c46ff49ddf5d8cc4d8f5de6))

## [1.4.2](https://github.com/bearinmindcat/morphe-patches/compare/v1.4.1...v1.4.2) (2026-10-06)

### 🐛 Bug Fixes

* customization and other screens no longer crash on android 10 ([9bac165](https://github.com/bearinmindcat/morphe-patches/commit/9bac165b01a94c97699376b692c46def333dfc89))

## [1.4.1](https://github.com/bearinmindcat/morphe-patches/compare/v1.4.0...v1.4.1) (2026-10-06)

### 🐛 Bug Fixes

* black theme no longer overrides the theme picked in maps settings ([5d9df9e](https://github.com/bearinmindcat/morphe-patches/commit/5d9df9e14f7af9662ad2fa1948e8d7167a9c8883))

## [1.4.0](https://github.com/bearinmindcat/morphe-patches/compare/v1.3.0...v1.4.0) (2026-10-06)

### 🐛 Bug Fixes

* fixed issue with zoom buttons floating over pulled up menu ([65878f1](https://github.com/bearinmindcat/morphe-patches/commit/65878f16d29c0c55933a3c8eaa6c2f723f0d00a4))
* fixed layout for landscape zoom control icons ([5e8783c](https://github.com/bearinmindcat/morphe-patches/commit/5e8783c9f8c6809a78f45c2981be1fe9b03b5a96))

### ✨ New Features

* add hide ai toggle (know before you go & gemini review summaries) ([efc79d7](https://github.com/bearinmindcat/morphe-patches/commit/efc79d71a2fe72b581724a0c54e120024934cc9c))

## [1.3.0](https://github.com/bearinmindcat/morphe-patches/compare/v1.2.0...v1.3.0) (2026-09-30)

### ✨ New Features

* add locally saved bookmarks & pins (also added timeline and recent searches) ([d6d4604](https://github.com/bearinmindcat/morphe-patches/commit/d6d460499327aa32b7de29c750d42313dec166ed))

## [1.2.0](https://github.com/bearinmindcat/morphe-patches/compare/v1.1.0...v1.2.0) (2026-09-26)

### ✨ New Features

* add 120 hz refresh rate toggle ([cf4ee62](https://github.com/bearinmindcat/morphe-patches/commit/cf4ee6245cef8e99ee74f5f9f400f468a963b032))

## [1.1.0](https://github.com/bearinmindcat/morphe-patches/compare/v1.0.5...v1.1.0) (2026-09-26)

### ✨ New Features

* added power saving nav toggle for all devices (may work on implementing powersaving throughout whole device) ([adc3853](https://github.com/bearinmindcat/morphe-patches/commit/adc385318951da08a3a9ba17ba7538daa22012b6))

## [1.0.5](https://github.com/bearinmindcat/morphe-patches/compare/v1.0.4...v1.0.5) (2026-09-24)

### 🐛 Bug Fixes

* fixed misc patching error with shapes ([14cf6cf](https://github.com/bearinmindcat/morphe-patches/commit/14cf6cf57fde7b23835b9f7002c13bbf2bbd95eb))

## [1.0.4](https://github.com/bearinmindcat/morphe-patches/compare/v1.0.3...v1.0.4) (2026-09-24)

### 🐛 Bug Fixes

* fixed crash when stock maps was not installed, maps api now targets changed package name ([c769d38](https://github.com/bearinmindcat/morphe-patches/commit/c769d3812fe9b3ee48da93f304d1c0aa9c3cb420))

## [1.0.3](https://github.com/bearinmindcat/morphe-patches/compare/v1.0.2...v1.0.3) (2026-09-24)

### 🐛 Bug Fixes

* android api as default location source ([154342a](https://github.com/bearinmindcat/morphe-patches/commit/154342a46b4503ae8cbbdd1988813e00557f462d))

## [1.0.2](https://github.com/bearinmindcat/morphe-patches/compare/v1.0.1...v1.0.2) (2026-09-24)

### 🐛 Bug Fixes

* update package name ([ce3a6dd](https://github.com/bearinmindcat/morphe-patches/commit/ce3a6dd1ff263625affec38fabe6140b24dd248b))

## [1.0.1](https://github.com/bearinmindcat/morphe-patches/compare/v1.0.0...v1.0.1) (2026-09-24)

### 🐛 Bug Fixes

* install alongside stock google maps by default ([c5ff618](https://github.com/bearinmindcat/morphe-patches/commit/c5ff6183a80a35b391201d1435f096b638d9c8df))

## 1.0.0 (2026-09-24)

### ✨ New Features

* release v1.0.0 ungoogled maps patches ([9d52bb2](https://github.com/bearinmindcat/morphe-patches/commit/9d52bb25fc791e04680a0096ce5fa44fe1faa920))

## [1.13.1](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.13.0...v1.13.1) (2026-09-23)

### 🐛 Bug Fixes

* Black theme and Rectangle shapes leaving Settings labels invisible ([b328e8d](https://github.com/bearinmindcat/morphe-patches-test/commit/b328e8dd77f4618d0def670de38d4e80de50aafb))

## [1.13.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.12.1...v1.13.0) (2026-09-23)

### ✨ New Features

* Better offline maps, Proxy, Location source and the explore/tabs switches ([535e23a](https://github.com/bearinmindcat/morphe-patches-test/commit/535e23aceea5895964758fa18d443203f84c3a99))
* Remove permissions, and the shell tooling's remaining defaults ([576f3da](https://github.com/bearinmindcat/morphe-patches-test/commit/576f3da662aa65447358acc47528c2f6afbbe309))

## [1.12.1](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.12.0...v1.12.1) (2026-09-23)

### 🐛 Bug Fixes

* Change package name leaving the app's own components under the old name ([5fa102b](https://github.com/bearinmindcat/morphe-patches-test/commit/5fa102bcbfa96ee39b29f7b5281e947be8409f15))

## [1.12.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.11.0...v1.12.0) (2026-09-23)

### 🐛 Bug Fixes

* Blue pin missing the search bar's pin and bundling recoloured artwork ([41dc853](https://github.com/bearinmindcat/morphe-patches-test/commit/41dc853dc1933cb730a58487fa8318fbde838325))
* Hide ads crashing search and emptying the results list ([c71de4e](https://github.com/bearinmindcat/morphe-patches-test/commit/c71de4eb73f4574e93f88b7aada66c4c3353dc85))
* Hide explore feed only hiding the sheet on one branch ([e77fca3](https://github.com/bearinmindcat/morphe-patches-test/commit/e77fca36051f4e7bda4ffe9266b925c5b16a6784))
* Hide navigation tabs crashing Maps on launch ([f3921f5](https://github.com/bearinmindcat/morphe-patches-test/commit/f3921f57b17e26b3370b0662225af7fbe345f606))
* Sign-in toast calling View methods on an uncast Object ([71260c2](https://github.com/bearinmindcat/morphe-patches-test/commit/71260c2df2f72b3e98b160b5198d037341a5e538))
* Trim account menu leaving half a row in the legacy builder ([d654a8b](https://github.com/bearinmindcat/morphe-patches-test/commit/d654a8b14901668479b9bfa2be386272a983b0ab))
* Your profile toast running the neighbouring row's action ([74777cf](https://github.com/bearinmindcat/morphe-patches-test/commit/74777cf721cc07be103902476b5f115f67d10bb2))

### ✨ New Features

* Black theme ([897d544](https://github.com/bearinmindcat/morphe-patches-test/commit/897d54461b2d7e53852dd743f0c14bff4627ddee))
* Customization screen ([0776d04](https://github.com/bearinmindcat/morphe-patches-test/commit/0776d04082310ae941078964107c0160f118ebce))
* Keep account sheet open ([19808dc](https://github.com/bearinmindcat/morphe-patches-test/commit/19808dc4474687649301293488cb3179f260484d))
* Legacy icon ([e5a25ef](https://github.com/bearinmindcat/morphe-patches-test/commit/e5a25eff11e1ddf0de7f1d0c2d286d82a6f02f52))
* Rectangle shapes ([7b24c76](https://github.com/bearinmindcat/morphe-patches-test/commit/7b24c765795542587867de055875d5b9f2c7caff))
* Zoom controls in navigation ([eb59117](https://github.com/bearinmindcat/morphe-patches-test/commit/eb59117ef367b3ef6b13bddfe5405d17a98c7363))

## [1.11.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.10.0...v1.11.0) (2026-09-22)

### ✨ New Features

* Blue pin ([f7cbd9b](https://github.com/bearinmindcat/morphe-patches-test/commit/f7cbd9b273257104100f96bd591c063e986b6d82))

## [1.10.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.9.0...v1.10.0) (2026-09-22)

### ✨ New Features

* Change package name ([68ef123](https://github.com/bearinmindcat/morphe-patches-test/commit/68ef1236ef197992fe4b91c2cb541be6dff36664))

## [1.9.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.8.0...v1.9.0) (2026-09-22)

### ✨ New Features

* Change app name ([c99b357](https://github.com/bearinmindcat/morphe-patches-test/commit/c99b357f4cd0168536566e38875aa96f7d1c452b))

## [1.8.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.7.0...v1.8.0) (2026-09-22)

### ✨ New Features

* Location provider toggle ([68ed8d0](https://github.com/bearinmindcat/morphe-patches-test/commit/68ed8d008b46d9a68096c07753248e036373d8e9))

## [1.7.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.6.0...v1.7.0) (2026-09-22)

### ✨ New Features

* Trim account menu ([bfa9e2f](https://github.com/bearinmindcat/morphe-patches-test/commit/bfa9e2f71f98ba7e9b968988a5e818b75b8f49bc))

## [1.6.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.5.0...v1.6.0) (2026-09-22)

### ✨ New Features

* Hide ads ([a183eb1](https://github.com/bearinmindcat/morphe-patches-test/commit/a183eb1fef3ca0f1fdc6df724a9e259a4e08eac8))
* Hide explore feed, Hide navigation tabs ([df37168](https://github.com/bearinmindcat/morphe-patches-test/commit/df371684137b328dbf59e38185fb3ed60a4577f8))
* Network location fallback ([379aa87](https://github.com/bearinmindcat/morphe-patches-test/commit/379aa872e2b29adb0b894be50d5a9d2cfec3bb2f))

## [1.5.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.4.0...v1.5.0) (2026-09-22)

### ✨ New Features

* Sign-in toast ([d10a2f9](https://github.com/bearinmindcat/morphe-patches-test/commit/d10a2f91eb6fb872d75a076075e0ab818d308f88))
* Your profile toast ([0633785](https://github.com/bearinmindcat/morphe-patches-test/commit/0633785e90179a70eec1ea2cbfc5687a60e20352))

## [1.4.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.3.0...v1.4.0) (2026-09-22)

### ✨ New Features

* Remove sign-in promo ([dd50e6d](https://github.com/bearinmindcat/morphe-patches-test/commit/dd50e6d96db0c87d824c1334955826536bda489f))
* Remove telemetry now also drops ad beacons ([8d02d58](https://github.com/bearinmindcat/morphe-patches-test/commit/8d02d581bf1e03e5698effdd8d53e9fd9de1f0b4))

## [1.3.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.2.0...v1.3.0) (2026-09-22)

### ✨ New Features

* Bypass Play Services checks ([a8f865f](https://github.com/bearinmindcat/morphe-patches-test/commit/a8f865fc894db327df617c62607d02fd3f6f7c09))
* Hide section title ([8eca3fa](https://github.com/bearinmindcat/morphe-patches-test/commit/8eca3faa329a4593a31cc9b879891a90829269e0))
* Hide sign-in button ([88518e4](https://github.com/bearinmindcat/morphe-patches-test/commit/88518e406b1459fd69e44a0a0059cc3a97cdbf58))
* Restore map data ([b707bc6](https://github.com/bearinmindcat/morphe-patches-test/commit/b707bc6bba9b13afcbb32962cfa20f39e7f1e820))

## [1.2.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.1.0...v1.2.0) (2026-09-22)

### ✨ New Features

* Remove telemetry ([e50d1d7](https://github.com/bearinmindcat/morphe-patches-test/commit/e50d1d759ace0d323c4be75d4300ca81f087bc16))

## [1.1.0](https://github.com/bearinmindcat/morphe-patches-test/compare/v1.0.0...v1.1.0) (2026-09-22)

### ✨ New Features

* Hide login promo ([2a8b214](https://github.com/bearinmindcat/morphe-patches-test/commit/2a8b214c4728ef0def061708980f6648008fe167))

## 1.0.0 (2026-09-22)

### ✨ New Features

* initial commit ungoogled maps patches ([c1051c3](https://github.com/bearinmindcat/morphe-patches-test/commit/c1051c38cd6e178f1f6e2f2115327bbd4f10c0c9))
